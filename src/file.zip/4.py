import socket

# 서버(통신을 받는 차량)
def v2v_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 8080))
    server_socket.listen(1)
    print("V2V 서버가 시작되었습니다. 연결 대기 중...")
    client_socket, addr = server_socket.accept()
    print(f"{addr}가 연결되었습니다.")
    
    data = client_socket.recv(1024).decode()
    print("수신된 데이터:", data)
    client_socket.close()

# 클라이언트(역주행 차량 경고 전송)
def v2v_client(message):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('127.0.0.1', 8080))  # 서버 IP로 연결
    client_socket.send(message.encode())
    client_socket.close()

# 서버 실행 (다른 차량)
# v2v_server()

# 클라이언트 실행 (역주행 차량 경고 전송)
# v2v_client("경고: 역주행 차량이 접근 중입니다.")
