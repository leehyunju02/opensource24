from gtts import gTTS
import os

# 음성 경고 생성
def voice_warning(message):
    tts = gTTS(text=message, lang='ko')
    tts.save("warning.mp3")
    os.system("mpg321 warning.mp3")  # mpg321 또는 기본 미디어 플레이어 사용

# 경고 메시지
voice_warning("경고! 역주행 차량이 접근 중입니다.")
