from geopy.geocoders import Nominatim
from geopy.distance import geodesic

# GPS 좌표 예시
vehicle_location = (37.5665, 126.9780)  # 서울
wrong_way_location = (37.5700, 126.9770)  # 역주행 위치 예시

# 위치 정보를 통해 도로 분석
geolocator = Nominatim(user_agent="geoapiExercises")
location = geolocator.reverse(vehicle_location)
print("차량 위치:", location.address)

# 역주행 차량과의 거리 계산
distance = geodesic(vehicle_location, wrong_way_location).meters
print(f"역주행 차량과의 거리: {distance:.2f} meters")

if distance < 100:  # 경고 기준 설정
    print("경고: 역주행 차량이 접근 중입니다!")
